package com.example.appmarvel;

public class Marvel {

    private String name;
    private String URL;
    private String text;
    //private String niveau;

    public String getName() {
        return name;
    }

    public String getURL() {
        return URL;
    }

    public String getText() { return text; }
}
